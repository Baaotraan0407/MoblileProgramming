// Interface OnDialogCloseListener
package com.example.todolist;

import android.content.DialogInterface;

public interface OnDialogCloseListener {
    void onDialogClose(DialogInterface dialogInterface);
}
